#include "DataFunctions.h"

using namespace std;

void *myrealloc(void *ptr, size_t size){
	/* There might be a realloc() out there that doesn't like reallocting NULL pointers, so we take care of it here */
	if (ptr)
		return realloc(ptr, size);
	else
		return malloc(size);
}

int write_data2(void *ptr, size_t size, size_t nmemb, void *data)
{

	size_t realsize = size * nmemb;
	struct MemoryStruct *mem = (struct MemoryStruct *)data;

	mem->memory = (char *)myrealloc(mem->memory, mem->size + realsize + 1);
	if (mem->memory) {
		memcpy(&(mem->memory[mem->size]), ptr, realsize);
		mem->size += realsize;
		mem->memory[mem->size] = 0;
	}
	return realsize;

}

//Change date formate to seconds
string getTimeinSeconds(string Time){
	std::tm t = { 0 };
	std::istringstream ssTime(Time);
	char time[100];
	memset(time, 0, 100);
	if (ssTime >> std::get_time(&t, "%Y-%m-%dT%H:%M:%S")){
		cout << std::put_time(&t, "%c %Z") << "\n"
			<< std::mktime(&t) << "\n";
		sprintf(time, "%lld", mktime(&t));
		return string(time);
	}
	else{
		cout << "Parse failed\n";
		return "";
	}
}

//Read the EPS data into 3 different group of stocks
void readESPData(vector<stock>& highVec, vector<stock>& midVec, vector<stock>& lowVec) {
	string line;
	ifstream file("ESP.csv"); // Open ESP file
	if (file.is_open()) {
		getline(file, line);
		while (getline(file, line)) {
			//Find the location of the seperation of , in the line
			size_t c1 = line.find(',');
			size_t c2 = line.find(',', c1 + 1);
			size_t c3 = line.find(',', c2 + 1);
			size_t c4 = line.find(',', c3 + 1);
			size_t c5 = line.find(',', c4 + 1);
			size_t c6 = line.find(',', c5 + 1);

			//Create a stock
			stock tempStock(line.substr(0, c1), line.substr(c1 + 1, c2 - c1 - 1), stod(line.substr(c2 + 1, c3 - c2 - 1)),
				stod(line.substr(c3 + 1, c4 - c3 - 1)), stod(line.substr(c4 + 1, c5 - c4 - 1)), line.substr(c5 + 1, c6 - c5 - 1),
				line.substr(c6 + 1));
			//Seperate it into 3 groups of vectors
			if (tempStock.getPerformance() > 6.5)
				highVec.push_back(tempStock);
			else if (tempStock.getPerformance() < 0)
				lowVec.push_back(tempStock);
			else
				midVec.push_back(tempStock);
		}

		file.close();
	}
	else
		cerr << "Unable to open file" << endl;
}

//Pass in the stock vector to get the yahoo data for those stocks
void GetYahooData(vector<stock>& stVec, map<string, stock>& stMap) {
	vector<stock>::iterator itr = stVec.begin();

	struct MemoryStruct data;
	data.memory = NULL;
	data.size = 0;
	//file pointer to create file that store the data  
	FILE *fp;

	/* declaration of an object CURL */
	CURL *handle;

	/* result of the whole process */
	CURLcode result;

	/* the first functions */
	/* set up the program environment that libcurl needs */
	curl_global_init(CURL_GLOBAL_ALL);

	/* curl_easy_init() returns a CURL easy handle that you're gonna reuse in other easy functions*/
	handle = curl_easy_init();


	/* if everything's all right with the easy handle... */
	if (handle){
		//Set Up cookies using cookies.txt file
		string sCookies, sCrumb;
		fp = fopen("cookies.txt", "r");
		char cCookies[100];
		if (fp) {
			while (fscanf(fp, "%s", cCookies) != EOF);
			fclose(fp);
		}
		else
			cerr << "cookies.txt does not exists" << endl;

		sCookies = cCookies;

		while (true){
			sCookies.clear();
			sCrumb.clear();

			//The full URL to get/put 
			curl_easy_setopt(handle, CURLOPT_URL, "https://finance.yahoo.com/quote/AMZN/history");
			// Set if we should verify the peer in ssl handshake, set 1 to verify. 
			curl_easy_setopt(handle, CURLOPT_SSL_VERIFYPEER, 0);
			/*Set if we should verify the Common name from the peer certificate in ssl handshake, set 1 to check existence, 2 to ensure
			that it matches the provided hostname. */
			curl_easy_setopt(handle, CURLOPT_SSL_VERIFYHOST, 0);
			/* Specify which file name to write all known cookies in after completed
			operation. Set file name to "-" (dash) to make it go to stdout. */
			curl_easy_setopt(handle, CURLOPT_COOKIEJAR, "cookies.txt");
			/* point to a file to read the initial cookies from, also enables
			"cookie awareness" */
			curl_easy_setopt(handle, CURLOPT_COOKIEFILE, "cookies.txt");
			/*Set the Accept - Encoding string.Use this to tell a server you would like
			the response to be compressed. */
			curl_easy_setopt(handle, CURLOPT_ENCODING, "");

			curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, write_data2);
			curl_easy_setopt(handle, CURLOPT_WRITEDATA, (void *)&data);

			/* perform, then store the expected code in 'result'*/
			result = curl_easy_perform(handle);

			/* Check for errors */
			if (result != CURLE_OK){
				/* if errors have occurred, tell us what is wrong with 'result'*/
				fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(result));
				free(data.memory);
				data.memory = NULL;
				data.size = 0;
				continue;
			}
			else{
				char cKey[] = "CrumbStore\":{\"crumb\":\"";
				char *ptr1 = strstr(data.memory, cKey);
				char *ptr2 = ptr1 + strlen(cKey);
				char *ptr3 = strstr(ptr2, "\"}");
				if (ptr3 != NULL)
					*ptr3 = NULL;

				sCrumb = ptr2;

				//Free the memory
				free(data.memory);
				data.memory = NULL;
				data.size = 0;
				break;
			}
		}

		while (true){
			if (itr == stVec.end())
				break;
			//Set up URL for download
			string urlA = "https://query1.finance.yahoo.com/v7/finance/download/";
			string symbol = itr->getTicker();
			string startTime = getTimeinSeconds(itr->getStartDate() + "T16:00:00");
			string endTime = getTimeinSeconds(itr->getEndDate() + "T16:00:00");
			string urlB = "?period1=";
			string urlC = "&period2=";
			string urlD = "&interval=1d&events=history&crumb=";
			string url = urlA + symbol + urlB + startTime + urlC + endTime + urlD + sCrumb;
			const char * cURL = url.c_str();
			const char * cookies = sCookies.c_str();
			curl_easy_setopt(handle, CURLOPT_COOKIE, cookies);
			curl_easy_setopt(handle, CURLOPT_URL, cURL);


			curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, write_data2);
			curl_easy_setopt(handle, CURLOPT_WRITEDATA, (void *)&data);
			result = curl_easy_perform(handle);
			/* Check for errors */
			if (result != CURLE_OK){
				/* if errors have occured, tell us wath's wrong with 'result*/
				fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(result));
				return;
			}

			stringstream sData;
			sData.str(data.memory);
			string line;
			vector<double> priceVec;
			getline(sData, line);
			cout << line << endl;
			while(getline(sData, line)) {
				if (line.find('D') != -1) // Check if the line is words or the data. Only push to vector if it is data.
					break;
				size_t pos = line.find(',', 45);
				size_t end = line.find_last_of(',');
				itr->pushBack(stod(line.substr(pos + 1, end - pos - 1))); //Add price to the vector

				cout << line << endl;
			}
			stMap.insert(pair<string, stock>(symbol, *itr));
			itr++;

			//Clear the Data Memory
			free(data.memory);
			data.memory = NULL;
			data.size = 0;
		}
			free(data.memory);
			data.size = 0;
	}
	else{
		fprintf(stderr, "Curl init failed!\n");
		return;
	}
	/* cleanup since you've used curl_easy_init */
	curl_easy_cleanup(handle);

	/* this function releases resources acquired by curl_global_init() */
	curl_global_cleanup();
}

//Get SPY Data
void getSPYData(map<string, size_t>& mpPosition, vector<double>& priceVec) {
	string symbol = "SPY";
	string startTime = getTimeinSeconds("2016-10-01T16:00:00");
	string endTime = getTimeinSeconds("2017-12-31T16:00:00");
	size_t i = -1; //Start at -1 to adjust for daily return

	struct MemoryStruct data;
	data.memory = NULL;
	data.size = 0;
	//file pointer to create file that store the data  
	FILE *fp;

	/* declaration of an object CURL */
	CURL *handle;

	/* result of the whole process */
	CURLcode result;

	/* the first functions */
	/* set up the program environment that libcurl needs */
	curl_global_init(CURL_GLOBAL_ALL);

	/* curl_easy_init() returns a CURL easy handle that you're gonna reuse in other easy functions*/
	handle = curl_easy_init();

	/* if everything's all right with the easy handle... */
	if (handle){
		string sCookies, sCrumb;
		if (sCookies.length() == 0 || sCrumb.length() == 0){
			//fp = fopen(outfilename, "w");

			curl_easy_setopt(handle, CURLOPT_URL, "https://finance.yahoo.com/quote/AMZN/history");
			curl_easy_setopt(handle, CURLOPT_SSL_VERIFYPEER, 0);
			curl_easy_setopt(handle, CURLOPT_SSL_VERIFYHOST, 0);
			curl_easy_setopt(handle, CURLOPT_COOKIEJAR, "cookies.txt");
			curl_easy_setopt(handle, CURLOPT_COOKIEFILE, "cookies.txt");
			curl_easy_setopt(handle, CURLOPT_ENCODING, "");

			curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, write_data2);
			curl_easy_setopt(handle, CURLOPT_WRITEDATA, (void *)&data);

			/* perform, then store the expected code in 'result'*/
			result = curl_easy_perform(handle);

			/* Check for errors */
			if (result != CURLE_OK){
				/* if errors have occurred, tell us what is wrong with 'result'*/
				fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(result));
				return;
			}

			char cKey[] = "CrumbStore\":{\"crumb\":\"";
			char *ptr1 = strstr(data.memory, cKey);
			char *ptr2 = ptr1 + strlen(cKey);
			char *ptr3 = strstr(ptr2, "\"}");
			if (ptr3 != NULL)
				*ptr3 = NULL;

			sCrumb = ptr2;

			fp = fopen("cookies.txt", "r");
			char cCookies[100];
			if (fp) {
				while (fscanf(fp, "%s", cCookies) != EOF);
				fclose(fp);
			}
			else
				cerr << "cookies.txt does not exists" << endl;

			sCookies = cCookies;
			free(data.memory);
			data.memory = NULL;
			data.size = 0;
		}

		string urlA = "https://query1.finance.yahoo.com/v7/finance/download/";
		string urlB = "?period1=";
		string urlC = "&period2=";
		string urlD = "&interval=1d&events=history&crumb=";
		string url = urlA + symbol + urlB + startTime + urlC + endTime + urlD + sCrumb;
		const char * cURL = url.c_str();
		const char * cookies = sCookies.c_str();
		curl_easy_setopt(handle, CURLOPT_COOKIE, cookies);
		curl_easy_setopt(handle, CURLOPT_URL, cURL);

		curl_easy_setopt(handle, CURLOPT_WRITEFUNCTION, write_data2);
		curl_easy_setopt(handle, CURLOPT_WRITEDATA, (void *)&data);
		result = curl_easy_perform(handle);
		/* Check for errors */
		if (result != CURLE_OK){
			/* if errors have occured, tell us wath's wrong with 'result*/
			fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(result));
			return;
		}

		stringstream sData;
		sData.str(data.memory);
		string line;
		getline(sData, line);
		cout << line << endl;
		while(getline(sData, line)) {
			string date = line.substr(0, line.find(','));
			mpPosition.insert(pair<string, size_t>(date, i));
			size_t pos = line.find(',', 45);
			size_t end = line.find_last_of(',');
			priceVec.push_back(stod(line.substr(pos + 1, end - pos - 1))); //Add price to the stack

			i++;
			cout << line << endl;
		}
	free(data.memory);
	data.size = 0;
	}

	else{
		fprintf(stderr, "Curl init failed!\n");
		return;
	}
	/* cleanup since you've used curl_easy_init */
	curl_easy_cleanup(handle);

	/* this function releases resources acquired by curl_global_init() */
	curl_global_cleanup();
}
