#pragma once

#include <string> 
#include <iostream>
#include <vector>
#include <map>
#include "Stock.h"
#include <process.h>
#include <Windows.h>
#include <time.h>
#include <algorithm>

class MultiCalcu
{

private:
	struct node
	{
		MultiCalcu* object;
		int num;
	};
	HANDLE threads[3];
	void(*pfun) (vector<stock>& stVec, map<string, stock>& stMap);
	map<string, stock> mpHigh;
	map<string, stock> mpMid;
	map<string, stock> mpLow;
	vector<stock> high;
	vector<stock> mid;
	vector<stock> low;
	vector < map<string, stock>> groups;
	int flag[3];
	double timebegin;
	bool sig;

public:
	static unsigned int __stdcall procWork(void  * lpParam);
	MultiCalcu(void(*pfun) (vector<stock>& stVec, map<string, stock>& stMap), vector<stock> &high, vector<stock> &low, vector<stock> &mid);
	vector < map<string, stock>> GetResult();
	double TimeCost();
	vector<stock> GetHigh()
	{
		
		return high;
	}
	vector<stock> GetMid()
	{
		return mid;
	}
	vector<stock> GetLow()
	{
		return low;
	}

};
