﻿using namespace std;
#include <vector>
#include <iostream>
#include <map>
#include "Stock.h"
#include <algorithm>

vector < map<string, stock>> GetSampleGroup(vector<stock> & low, vector<stock> & mid, vector<stock> & high);

vector<int> Rand_Generator(vector<stock> &group);

void Divide(map<string, vector<vector<double>>> &result);
