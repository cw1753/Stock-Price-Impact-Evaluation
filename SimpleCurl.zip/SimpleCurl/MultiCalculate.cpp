#include "MultiCalculate.h"


MultiCalcu::MultiCalcu(void(*pfun) (vector<stock>& stVec, map<string, stock>& stMap), vector<stock> &high, vector<stock> &low, vector<stock> &mid)
{
	sig = true;
	flag[0] = 0; flag[0] = 0; flag[0] = 0;
	timebegin = time(0);

	this->high = high;
	this->mid = mid;
	this->low = low;
	this->pfun = pfun;
	struct node *temp[3];
	for (int i = 0; i <= 2; i++)
	{
		temp[i] = new node;
		temp[i]->num = i;
		temp[i]->object = this;
	}
	for (int i = 0; i <= 2; i++)
	{
		threads[i] = (HANDLE)_beginthreadex(NULL, 0, procWork, temp[i], 0, NULL);
	}
}


unsigned int __stdcall MultiCalcu::procWork(void  * lpParam)
{
	node * pthis = (node *)lpParam;
	int mark = 0;
	while (1)
	{
		if (pthis->object->sig)
		{
			switch (pthis->num)
			{
			case 0:
				cout << "start working" << endl;
				pthis->object->pfun(pthis->object->high, pthis->object->mpHigh);
				mark = 1;
				break;
			case 1:
				cout << "start working" << endl;
				pthis->object->pfun(pthis->object->mid, pthis->object->mpMid);
				mark = 1;
				break;
			case 2:
				cout << "start working" << endl;
				pthis->object->pfun(pthis->object->low, pthis->object->mpLow);
				mark = 1;
				break;
			default:
				break;
			}
		}
		if (mark==1)
		{
			break;
		}
	}
	pthis->object->flag[pthis->num] = 1;
	return pthis->num;
	
}

vector < map<string, stock>> MultiCalcu::GetResult()
{
	while (1)
	{
		int k = flag[0] + flag[1] + flag[2];
		if (k == 3)
		{
			for (int i = 0; i <= 2; i++)
			{
				CloseHandle(threads[i]);
				threads[i] = NULL;
			}
			break;
		}
	}
	vector < map<string, stock>> groups;


	groups.push_back(mpLow);
	groups.push_back(mpMid);
	groups.push_back(mpHigh);

	return groups;
}

double MultiCalcu::TimeCost()
{
	return (time(0) - timebegin) / 60.000;
}


