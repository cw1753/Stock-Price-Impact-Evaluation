#pragma once
#ifndef Calulate_h
#define Calculate_h


#include <string> 
#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <map>
#include "Stock.h"

using namespace std;

//**********overload the vector*************

template<class T>
vector<T> operator-(const vector<T> &x, const vector<T> &y);  //overload for the part e

void operator+(map<string, vector<vector<double>>> & x, map<string, vector<vector<double>>> & y);
template<class T>
vector<T> operator/(const vector<double> & x, const double & y);

//**********overload the vector*************

vector<double> DailyReturn(vector<double> Stock_Series); //calculate the stock's daily return
vector<double> AART(vector<vector<double>> diff_info); //calcuate the AART
vector<double> CAAR(vector<double> AART_result); //calculate the CAAR

map<string, vector<vector<double>>> MatrixInfo(vector<map<string, stock>> Group_Info, map<string, size_t> ETFPos_Check, vector<double> ETFPrice); //show in the 3*3 matrix, which the last column is 1*1 vector

#endif // Calulate_h


