﻿#include <stdio.h>
#include <string> 
#include <iostream>
#include <sstream>  
#include <vector>
#include <locale>
#include <iomanip>
#include "curl.h"
#include"Input.h"


//MyCode
#include<fstream>
#include<stack>
#include<map>
#include "Stock.h"
#include "Calculate.h"
#include "DataFunctions.h"
#include "MultiCalculate.h"
#include "Sampling.h"


using namespace std;


int main()
{
	int choice;
	char data, menu_again;
	//Testing
	time_t timeBegin, timeEnd;
	timeBegin = time(NULL);


	// //1. Creating STL vectors in which stock is the data type to store the information for all groups.
	vector<stock> high;
	vector<stock> mid;
	vector<stock> low;
	//map<string, stock> mpHigh;
	//map<string, stock> mpMid;
	//map<string, stock> mpLow;
	map<string, vector<vector<double>>> result; //Store the ARR and CRR in this map
	vector<map<string, stock>> po;
	map<string, size_t> SPYVectorPosition;
	vector<double> SPYPriceVec;
	vector < map<string, stock>> groups;
	vector<double> SPYDailyReturn;
	map<string, size_t>::iterator ite;
	vector<map<string, stock>>::iterator ite2 = groups.begin();



beginning:
	system("cls");
	cout << "Welcome to our system!" << endl;
	cout << "This system is for evaluating the impact of earning report on stock price." << endl;
	cout << "You have FIVE options to select." << endl;
	cout << "******************************MENU******************************" << endl;
	cout << "Please type your choice." << endl;
	cout << "1. Retrieve historical price data for all stocks." << endl;
	cout << "2. Pull information for one stock from one group." << endl;
	cout << "3. Show AAR or CAAR for one group." << endl;
	cout << "4. Show the Excel graph with CAAR for all 3 groups." << endl;
	cout << "5. Exit your program." << endl;
	cin >> choice;
	switch (choice)
	{
	case 1:
		while (true)
		{
			cout << "Downloading data will take a few minutes. Thank you for your patience." << endl;
			//2.Read CSV file
			readESPData(high, mid, low);


			//3.Downloading data fron Yahoo Finance
			MultiCalcu All_SP500_Info(GetYahooData, high, low, mid);
			groups = All_SP500_Info.GetResult();
			low = All_SP500_Info.GetLow();
			mid = All_SP500_Info.GetMid();
			high = All_SP500_Info.GetHigh();

			if (low[1].GetPrice().size() == 0 || mid[1].GetPrice().size() == 0 || high[1].GetPrice().size() == 0)
			{
				cout << "Woops. Something wrong." << endl;
				system("pause");
				return 0;
			}


			//4. Get SPY
			getSPYData(SPYVectorPosition, SPYPriceVec);
			SPYDailyReturn = DailyReturn(SPYPriceVec);
			ite = SPYVectorPosition.begin();
			SPYVectorPosition.erase(ite);
			cout << "Your data has already been downloaded along with one year data of SPY." << endl;


			cout << "\n\nTesing" << endl;
			vector<stock>::iterator id1 = low.begin();
			while (id1 != low.end()) {
				if ((id1->GetPrice()).size() == 0) {
					cout << id1->getTicker() << endl;
				}
				id1++;
			}
			vector<stock>::iterator id2 = mid.begin();
			while (id2 != mid.end()) {
				if ((id2->GetPrice()).size() == 0) {
					cout << id2->getTicker() << endl;
				}
				id2++;
			}
			vector<stock>::iterator id3 = high.begin();
			while (id3 < high.end()) {
				if ((id3->GetPrice()).size() == 0) {
					cout << id3->getTicker() << endl;
				}
				id3++;
			}
			break;
		}
		break;
	case 2:
	Case_2:
		cout << "Have you already retrieved the data by using choice 1 in the menu (Y/y or N/y)" << endl;
		cin >> data;
		if (data == 'Y' || data == 'y')
		{
		Getticker:
			cout << "Please type in the stock ticker (in Upper Case): " << endl;
			string ticker;
			cin >> ticker;
			cout << endl;
			int count = 0;
			char ticker_decision;
			for (int i = 0; i < 3; i++) {
				for (auto it = groups[i].begin(); it != groups[i].end(); it++)
				{
					if (it->second.getTicker() == ticker)
					{
						it->second.printStock();
						count++;
						break;
					}
				}

			}
			if (count = 0)
			{
				cout << "Sorry, we cannot find the corresponding stock." << endl;
			}
			count--;
		Getticker2:
			cout << "Do you want to try another stock? Please type Y/y for Yes or N/n for No." << endl;
			cin >> ticker_decision;
			if (ticker_decision == 'Y' || ticker_decision == 'y')
				goto Getticker;
			else if (ticker_decision == 'N' || ticker_decision == 'n')
				break;
			else
			{
				cout << "Please type Y/y for Yes or N/n for No." << endl;
				goto Getticker2;
			}


			system("pause");
		}
		else if (data == 'N' || data == 'n')
		{
			cout << "Do not worry. We will retrieve the data for you." << endl;
			cout << "Downloading data will take a few minutes. Thank you for your patience." << endl;
			//2.Read CSV file
			readESPData(high, mid, low);


			//3.Downing data fron Yahoo Finance
			MultiCalcu All_SP500_Info(GetYahooData, high, low, mid);
			groups = All_SP500_Info.GetResult();
			low = All_SP500_Info.GetLow();
			mid = All_SP500_Info.GetMid();
			high = All_SP500_Info.GetHigh();



			//4.Get SPY
			getSPYData(SPYVectorPosition, SPYPriceVec);
			SPYDailyReturn = DailyReturn(SPYPriceVec);
			ite = SPYVectorPosition.begin();
			SPYVectorPosition.erase(ite);
			cout << "Your data has already been downloaded along with one year data of SPY." << endl;
			goto Getticker;
		}
		else
		{
			cout << "Please type Y/y or N/n" << endl;
			goto Case_2;
		}
		break;
	case 3:
	Case_3:
		cout << "Have you already retrieved the data by using choice 1 in the menu (Y or N)" << endl;
		cin >> data;
		if (data == 'Y' || data == 'y')
		{
			po = GetSampleGroup(low, mid, high);
			result = MatrixInfo(po, SPYVectorPosition, SPYDailyReturn);

			for (int i = 1; i <= 99; i++) //Next 99 time sampling
			{

				po = GetSampleGroup(low, mid, high);
				map<string, vector<vector<double>>> temp = MatrixInfo(po, SPYVectorPosition, SPYDailyReturn);
				result + temp; //overload + update result

			}

			Divide(result); //Divided by 99
			cout << "Calculations are done." << endl;
		again:
			cout << "Please type the name of the group you want." << endl;
			cout << "Please type high, med, or low" << endl;
			string group_no;
			cin >> group_no;
			int counter = 1;
			if (group_no == "high" || group_no == "med" || group_no == "low")
			{
				for (auto it = result[group_no][0].begin(), it2 = result[group_no][1].begin(); it != result[group_no][0].end(); it++, it2++)
				{
					cout << "stock" << counter << ":" << "AAR" << ": " << *it << "" << "CAAR" << ":" << *it2 << endl;
				}
			}
			else {

				goto again;
			}
		again_2:
			cout << "Do you still want to look at the AAR and CAAR of other groups? Please type Y for Yes or N for No" << endl;
			char decision_3;
			cin >> decision_3;
			if (decision_3 == 'Y' || decision_3 == 'y')
				goto again;
			else if (decision_3 == 'N' || decision_3 == 'n')
			{
				cout << "Thank you for using our system" << endl;
				break;

			}
			else
			{
				cout << "Please type Y for Yes or N for No." << endl;
				goto again_2;
			}
		}
		else if (data == 'N' || data == 'n')
		{
			cout << "Do not worry. We will retrieve the data for you." << endl;
			cout << "Downloading data will take a few minutes. Thank you for your patience." << endl;
			//2. Read CSV file
			readESPData(high, mid, low);


			//3. Downloading data from Yahoo Finance
			MultiCalcu All_SP500_Info(GetYahooData, high, low, mid);
			vector < map<string, stock>> groups = All_SP500_Info.GetResult();



			//4.Get SPY
			getSPYData(SPYVectorPosition, SPYPriceVec);
			SPYDailyReturn = DailyReturn(SPYPriceVec);
			ite = SPYVectorPosition.begin();
			SPYVectorPosition.erase(ite);
			cout << "Your data has already been downloaded along with one year data of SPY." << endl;
			goto again;

		}
		else
		{
			cout << "Please type Y/y or N/n" << endl;
			goto Case_3;
		}
		break;
	case 4:
	Case_4:
		cout << "Have you already calculated the result by using choice 3 in the menu (Y or N)" << endl;
		cin >> data;
		if (data == 'Y' || data == 'y')
		{
			Graph(result);

		}
		else if (data == 'N' || data == 'n')
		{
			cout << "Do not worry. We will calculate the data for you." << endl;
			download_answer:
			cout << "Have you already downloaded the data in your computer? Please type Y for Yes or N for No." << endl;
			char download;
			cin >> download;
			if (download == 'Y' || download == 'n')
			{
				po = GetSampleGroup(low, mid, high);
				result = MatrixInfo(po, SPYVectorPosition, SPYDailyReturn);

				for (int i = 1; i <= 99; i++) //Next 99 time sampling
				{

					po = GetSampleGroup(low, mid, high);
					map<string, vector<vector<double>>> temp = MatrixInfo(po, SPYVectorPosition, SPYDailyReturn);
					result + temp; //overload + update result

				}

				Divide(result); //Divided by 99
				Graph(result);
			}
			else if (download == 'N' || download == 'n')
			{
				cout << "Do not worry. We will retrieve the data for you." << endl;
				cout << "Downloading data will take a few minutes. Thank you for your patience." << endl;
				//2.Read CSV file
				readESPData(high, mid, low);


				//3.Downloading data fron Yahoo Finance
				MultiCalcu All_SP500_Info(GetYahooData, high, low, mid);
				groups = All_SP500_Info.GetResult();
				low = All_SP500_Info.GetLow();
				mid = All_SP500_Info.GetMid();
				high = All_SP500_Info.GetHigh();

				if (low[1].GetPrice().size() == 0 || mid[1].GetPrice().size() == 0 || high[1].GetPrice().size() == 0)
				{
					cout << "Woops. Something wrong." << endl;
					system("pause");
					return 0;
				}

				//4. Get SPY
				getSPYData(SPYVectorPosition, SPYPriceVec);
				SPYDailyReturn = DailyReturn(SPYPriceVec);
				ite = SPYVectorPosition.begin();
				SPYVectorPosition.erase(ite);
	

				cout << "Your data has already been downloaded along with one year data of SPY." << endl;
				cout << "Now we are calculating the data for you." << endl;

				po = GetSampleGroup(low, mid, high);
				result = MatrixInfo(po, SPYVectorPosition, SPYDailyReturn);

				for (int i = 1; i <= 99; i++) //Next 99 time sampling
				{

					po = GetSampleGroup(low, mid, high);
					map<string, vector<vector<double>>> temp = MatrixInfo(po, SPYVectorPosition, SPYDailyReturn);
					result + temp; //overload + update result

				}

				Divide(result); //Divided by 99
				cout << "Calculations are done." << endl;
				Graph(result);
				cout << "The graph is in the Excel." << endl;

			}
			else
			{
				cout << "Please type Y/y or N/n" << endl;
				goto download_answer;
			}
			
		}
		else
		{
			cout << "Please type Y/y or N/n" << endl;
			goto Case_4;
		}
		break;
	case 5:
		cout << "You have exited the system successfully." << endl;
		cout << "Thank you for using our system!" << endl;
		break;
	default:
		cout << "Sorry. We do not have this option." << endl;
		cout << "Please type an integer from {1,2,3,4,5}." << endl;
		goto beginning;
	}
	if (choice != 5)
	{
		cout << "Would you like to use other options in this system?" << endl;
	choice_again:
		cout << "Please type Y for YES or N for NO" << endl;
		cin >> menu_again;
		if (menu_again == 'Y' || menu_again == 'y')
			goto beginning;
		else if (menu_again == 'N' || menu_again == 'n')
			cout << "Thank you for using our system" << endl;
		else
			goto choice_again;
	}

	system("pause");
	return 0;
}




