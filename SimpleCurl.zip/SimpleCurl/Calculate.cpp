﻿#include <string> 
#include <iostream>
#include <vector>
#include <map>
#include "Stock.h"

using namespace std;

template<class T>
vector<T> operator-(const vector<T> &x, const vector<T> &y)  //overload for the part e
{
    vector<T> result;
    T temp;
    for (int i = 0; i <= x.size() - 1; i++)
    {
        temp = x[i] - y[i];
        result.push_back(temp);
    }
    return result;
    
}

void operator+(map<string, vector<vector<double>>> & x, map<string, vector<vector<double>>> & y)
{
	map<string, vector<vector<double>>>::iterator ite1=x.begin();
	map<string, vector<vector<double>>>::iterator ite2=y.begin();
	while (ite1!=x.end())
	{
		for (int i=0;i<=(*ite1).second[1].size()-1;i++)
		{
			(*ite1).second[1][i] += (*ite2).second[1][i];
			(*ite1).second[0][i] += (*ite2).second[0][i];
		}
		ite1++;
		ite2++;
	}
    
   
}

template<class T>
vector<T> operator/(const vector<double> & x, const double & y)
{
    
    vector<T> result;
    T temp;
    for (int i = 0; i <=x.size()-1; i++)
    {
        temp = x[i] / y;
        result.push_back(temp);
    }
    return results;
}

vector<double> DailyReturn(vector<double> Stock_Series) //calculate the stock's daily return
{
    vector<double> result;
    double shuju = 0.0;
    for (int i = 1; i <= Stock_Series.size() - 1; i++)
    {
        shuju = (Stock_Series[i] - Stock_Series[i - 1]) / Stock_Series[i - 1];
        result.push_back(shuju);
    }
    return result;
}

vector<double> AART(vector<vector<double>> diff_info)   //send in the diff_info
{
    vector<double> result;
    for (int i = 0; i <= diff_info[1].size() - 1; i++) //60 days
    {    double temp = 0.0;
        for (int j = 0; j <= diff_info.size() - 1; j++)//calcuate the sum of daily abnormal return
        {
            temp += diff_info[j][i];
        }
        temp /= diff_info.size();
        result.push_back(temp);
    }
    return result;
}

vector<double> CAAR(vector<double> AART_result)   //send in the vector we just get from part f to compute CAAR, which should return the size 1*60 vector
{
    vector<double> result;
    double temp = 0.0;
    for (int i = 0; i <= AART_result.size() - 1; i++)
    {
        temp += AART_result[i];
        result.push_back(temp);
    }
    return result;
}

static int c = 0;
map<string, vector<vector<double>>> MatrixInfo(vector<map<string, stock>> Group_Info, map<string, size_t> ETFPos_Check, vector<double> ETFPrice) //show in the 3*2 matrix
{
    //the first is a vector combined three maps, each stored 40 stocks information (high mid and low); the second index is a map for integers with workday date as a key; the third is the vector of the daily return of SPY

    // already know the first index vector is 0-low, 1-med, 2-high
    map<string, vector<vector<double>>> result;  // create the return type, the return type is map, one index is string as stock name, second index include the AART, CAAR
    vector<vector<double>> diff_return;
    vector<double> temp1;
	c++;
    
    vector<double> temp3;
    int stardate = 0;
    double mean = 0;
    //calculate the each stock's daily return
    for (int j = 0; j <= Group_Info.size() - 1; j++)
    {
        diff_return.clear();
        
        
        map<string, stock>::iterator ite = Group_Info[j].begin(); //begin of the iterator
        while (ite != Group_Info[j].end())
        {
            temp1 = DailyReturn((*ite).second.GetPrice());// pass the stock price to get the daily return
            //do the time matching
			stardate = ETFPos_Check[(*ite).second.getStartDate()];//get the ETF price by using the map<string, int>ETFPos_check map
			vector<double> temp2(ETFPrice.begin() + stardate, ETFPrice.begin() + stardate + 60);
           
            //use the overloaded function to get the temp3
            temp3 = temp1 - temp2;
            //get the difference of return
            //adding this one at the end of vector
            diff_return.push_back(temp3);
            
            ite++;
        }
        //go through the whole map, and calculate the aar and caar
        temp1.clear();
        temp1 = AART(diff_return); //calculate the AART
        diff_return.clear();
        temp3.clear();
        temp3 = CAAR(temp1);//calculate the CAAR
        diff_return.push_back(temp1);
        diff_return.push_back(temp3);
        temp3.clear();

        switch (j)
        {
                
            case 0:
                
                result["low"] = diff_return;
                break;
            case 1:
                result["med"] = diff_return;
                break;
            case 2:
                result["high"] = diff_return;
                break;
            default:
                break;
                
        }
        diff_return.clear();
    }
    return result;
};
