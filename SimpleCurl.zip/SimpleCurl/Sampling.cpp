﻿#include "Sampling.h"

vector<int> Rand_Generator(vector<stock> &group)
{
	int temp = 0;
	vector<int> arry;
	vector<int>::iterator ite;
	for (int i=0;i<=39;i++){
		temp = rand()%(group.size());
		while (true){
			ite = find(arry.begin(),arry.end(),temp);
			if (ite==arry.end()){ //if the random index aren't added to the arry yet.
				if (group[temp].getSeriesSize() > 0) {
					arry.push_back(temp);
					break;
				}
			}
			else{
				temp = rand() % (group.size());
			}
		}
	}
	return arry;
}

vector < map<string, stock>> GetSampleGroup(vector<stock> & low, vector<stock> & mid, vector<stock> & high)
{
	vector < map<string, stock>> result;//0代表low, 1代表mid，2代表high'
	map<string, stock> low_group;
	map<string, stock> mid_group;
	map<string, stock> high_group;
	
	vector<int> Randarry1= Rand_Generator(low); 
	vector<int> Randarry2 = Rand_Generator(mid);
	vector<int> Randarry3 = Rand_Generator(high);


	for (int i=0;i<=39;i++)
	{
		low_group[low[Randarry1[i]].getTicker()] = low[Randarry1[i]];
		mid_group[mid[Randarry2[i]].getTicker()] = mid[Randarry2[i]];
		high_group[high[Randarry3[i]].getTicker()] = high[Randarry3[i]];
	}
	result.push_back(low_group);
	result.push_back(mid_group);
	result.push_back(high_group);
	return result;
}

void Divide(map<string, vector<vector<double>>> &result)
{
	
	map<string, vector<vector<double>>>::iterator ite = result.begin();
	while (ite!=result.end())
	{
		for (int i=0;i<=(*ite).second[1].size()-1;i++)
		{
			(*ite).second[1][i] /= 100.000;
		}
		ite++;
	}
}


