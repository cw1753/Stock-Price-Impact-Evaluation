#pragma once
#ifndef DataFunctions_h
#define DataFunctions_h

#include <stdio.h>
#include <string> 
#include <iostream>
#include <sstream>  
#include <vector>
#include <locale>
#include <iomanip>
#include "curl.h"

//MyCode
#include<fstream>
#include<stack>
#include<map>
#include "stock.h"
#include "Calculate.h"


using namespace std;

struct MemoryStruct {
	char *memory;
	size_t size;
};

void *myrealloc(void *ptr, size_t size); //There might be a realloc() out there that doesn't like reallocting 	NULL pointers, so we take care of it here 

int write_data2(void *ptr, size_t size, size_t nmemb, void *data);

string getTimeinSeconds(string Time); //Change date formate to seconds

//MyCode
void readESPData(vector<stock>& highVec, vector<stock>& midVec, vector<stock>& lowVec); //Read the EPS data into 3 different group of stocks

void GetYahooData(vector<stock>& stVec, map<string, stock>& stMap); //Pass in the stock vector to get the yahoo data for those stocks

void getSPYData(map<string, size_t>& mpPosition, vector<double>& priceVec); //Get SPY Data

#endif // DataFunctions_h