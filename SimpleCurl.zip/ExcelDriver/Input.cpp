#include "Input.h"
#include"stdafx.h"
#include<map>
#include<vector>
#include<string>
#include<list>
#include "VectorsAndMatrices\Vector.cpp"
#include "ExcelMechanisms.hpp"
#include "Geometry\range.cpp"
using namespace std;


Vector<double, long> Input_Parameter(vector<double> Old)//// Transfer the STL type from vector<double> into vector<double,long>, then we can use it as input parameter of function printInExcel defined in ExcelMechanisms.hpp
{
	Vector<double, long> New(Old.size());
	long index = New.MinIndex();
	for (int i = 0; i < Old.size(); i++)
	{
		New[index] = Old[i];
		index++;
	}
	return New;
}

void Graph(map<string,vector<vector<double>>> Result_Matrix)
{
	Vector<double, long> Days;
	list<Vector<double, long> > AAR;
	list<Vector<double, long> > CAAR;
	for (auto it = Result_Matrix.begin(); it != Result_Matrix.end(); it++)
	{
		AAR.push_back(Input_Parameter(it->second[0]));
		CAAR.push_back(Input_Parameter(it->second[1]));
	}
	Range<double> time_range(-30.0, 30.0);
	Days = time_range.mesh(60);
	list<std::string> labels;
	labels.push_back("High");
	labels.push_back("Low");
	labels.push_back("Medium");
	//string Title_AAR("AAR");
	string Title_CAAR("CAAR");
	string X("Time");
	string Y("Return");
	//printInExcel(Days, labels,CAAR, Title_AAR, X, Y)
	printInExcel(Days, labels, CAAR, Title_CAAR,X,Y);
}