#ifndef Stock_h
#define Stock_h
#include<iostream>
#include<string>
#include<vector>
#include <time.h>
using namespace std;

class stock {
public:
	//Parameter constructer
	stock()
	{

		double k = (rand() % 150 + 20) / 1.0005;
		dateStart = to_string(rand() % 250);
		for (int i = 0; i <= 60; i++)
		{
			k = (rand() % 150 + 20) / 1.0005;

			Price_Series.push_back(k);
		}
	}
	string getTicker() {
		return ticker;
	}
	string getStartDate() {
		return dateStart;
	}
	string getEndDate() {
		return dateEnd;
	}
	double getPerformance() {
		return performance;
	}
	void Info_Look()
	{
		for (int i = 0; i <= Price_Series.size() - 1; i++)
		{
			cout << Price_Series[i] << endl;
		}
	}
	const vector<double> GetPrice()
	{
		return Price_Series;
	}
private:
	string ticker, dateZero, dateStart, dateEnd;
	double actual, estimate, performance;
	vector<double> Price_Series;


};

#endif