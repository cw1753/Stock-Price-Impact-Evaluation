#ifndef Input_h
#define Input_h
#include "ExcelMechanisms.hpp"
#include<map>
#include<string>



Vector<double, long> Input_Parameter(vector<double> Old); // Transfer the STL type from vector<double> into vector<double,long>, then we can use it as input parameter of function printInExcel defined in ExcelMechanisms.hpp

void Graph(map<string,vector<vector<double>>> Result_Matrix);

#endif // !Input_h

