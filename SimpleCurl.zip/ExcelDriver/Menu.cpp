//#include<iostream>
//#include"Stock.h"
//#include"Input.h"
//#include"stdafx.h"
//#include "Calculate.cpp"
//#include <map>
//#include<vector>
//#include<string>
//using namespace std;
//
//
//
//map<string, vector<stock>> simulation() //��Ҫ����1��3*40����Ʊ��map
//{
////	map<string, vector<stock>> result;
//	vector<stock> temp;
//	for (int i = 0; i <= 39; i++)
//	{
//		stock pigu;
//		temp.push_back(pigu);
//
//	}
//	result["low"] = temp;
//	temp.clear();
//	for (int i = 0; i <= 39; i++)
//	{
//		stock pigu;
//		temp.push_back(pigu);
//
//	}
//	result["high"] = temp;
//	temp.clear();
//	for (int i = 0; i <= 39; i++)
//	{
//		stock pigu;
//		temp.push_back(pigu);
//
//	}
//	result["med"] = temp;
//
//	return result;
//
//
//
//};
//
//vector<double> simulation2() //��Ҫ����1��3*40����Ʊ��map
//{
//
//	vector<double> result;
//	for (int i = 0; i <= 250; i++)
//	{
//		int o = rand() % 20;
//		double k = (o - 10) / 100.000;
//		result.push_back(k);
//	}
//
//	return result;
//
//
//
//};
//
//map<string, int> simulaiton3()
//{
//	map<string, int> result;
//	for (int i = 0; i <= 250; i++)
//	{
//
//		result[std::to_string(i)] = i;
//	}
//	return result;
//
//};
//
//vector<map<string, stock>> simulaiton4()
//{
//	vector<map<string, stock>> result;
//	map<string, stock> group1;
//	map<string, stock> group2;
//	map<string, stock> group3;
//	for (int i = 0; i <= 39; i++)
//	{
//		stock temp;
//		group1[std::to_string(i)] = temp;
//
//	}
//	for (int i = 0; i <= 39; i++)
//	{
//		stock temp;
//		group2[std::to_string(i)] = temp;
//
//	}
//	for (int i = 0; i <= 39; i++)
//	{
//		stock temp;
//		group3[std::to_string(i)] = temp;
//
//	}
//	result.push_back(group1);
//	result.push_back(group2);
//	result.push_back(group3);
//	return result;
//
//};
//
////vector<map<string,vector<stock>>> Group_Info,map<string,int> ETFPos_Check, vector<double> ETFPrice
////int main()
////{
////
////
////
////	srand(time(unsigned int(0)));
////	map<string, vector<vector<double>>> juzhen = MatrixInfo(simulaiton4(), simulaiton3(), simulation2());
////	cout << "aa";
////	cout << juzhen["low"][2][0] << endl;
////	cout << juzhen["med"][2][0] << endl;
////	cout << juzhen["high"][2][0] << endl;
////	//Graph(juzhen);
////	system("pause");
////	return 0;
////}
//
///*
//int main()
//{
//	int choice;
//	char data, again;
//beginning:
//	system("cls");
//	cout << "Welcome to our system!" << endl;
//	cout << "This system is for evaluating the impact of earning report on stock price." << endl;
//	cout << "You have FIVE options to select." << endl;
//	cout << "******************************MENU******************************" << endl;
//	cout << "Please type your choice." << endl;
//	cout << "1. Retrieve historical price data for all stocks." << endl;
//	cout << "2. Pull information for one stock from one group." << endl;
//	cout << "3. Show AAR or CAAR for one group." << endl;
//	cout << "4. Show the Excel graph with CAAR for all 3 groups." << endl;
//	cout << "5. Exit your program." << endl;
//	cin >> choice;
//	switch (choice)
//	{
//	case 1:
//		cout << "You have selected choice 1." << endl;
//		break;
//	case 2:
//	Case_2:
//		cout << "Have you already retrieved the data by using choice 1 in the menu (Y/y or N/y)" << endl;
//		cin >> data;
//		if (data == 'Y' || data == 'y')
//		{
//			cout << "Information" << endl;
//		}
//		else if (data == 'N' || data == 'n')
//		{
//			cout << "Do not worry. We will retrieve the data for you." << endl;
//		}
//		else
//		{
//			cout << "Please type Y/y or N/n" << endl;
//			goto Case_2;
//		}
//		break;
//	case 3:
//	Case_3:
//		cout << "Have you already retrieved the data by using choice 1 in the menu (Y/y or N/y)" << endl;
//		cin >> data;
//		if (data == 'Y' || data == 'y')
//		{
//			cout << "Information" << endl;
//		}
//		else if (data == 'N' || data == 'n')
//		{
//			cout << "Do not worry. We will retrieve the data for you." << endl;
//		}
//		else
//		{
//			cout << "Please type Y/y or N/n" << endl;
//			goto Case_3;
//		}
//		break;
//	case 4:
//	Case_4:
//		cout << "Have you already retrieved the data by using choice 1 in the menu (Y/y or N/y)" << endl;
//		cin >> data;
//		if (data == 'Y' || data == 'y')
//		{
//			cout << "Information" << endl;
//		}
//		else if (data == 'N' || data == 'n')
//		{
//			cout << "Do not worry. We will retrieve the data for you." << endl;
//		}
//		else
//		{
//			cout << "Please type Y/y or N/n" << endl;
//			goto Case_4;
//		}
//		break;
//	case 5:
//		cout << "You have exited the system successfully." << endl;
//		cout << "Thank you for using our system!" << endl;
//		break;
//	default:
//		cout << "Sorry. We do not have this option." << endl;
//		cout << "Please type an integer from {1,2,3,4,5}." << endl;
//		goto beginning;
//	}
//	if (choice != 5)
//	{
//		cout << "Would you like to use other options in this system?" << endl;
//		cout << "Please type Y/y for YES or N/n for NO" << endl;
//		cin >> again;
//		if (again == 'Y' || again == 'y')
//			goto beginning;
//		else if (again == 'N' || again == 'n')
//			cout << "Thank you for using our system" << endl;
//		else
//			cout << "Please type a character Y/y or N/n" << endl;
//	}
//
//	system("pause");
//	return 0;
//}
//*/
//
///*
//Stock GetSPY()
//{
//	string symbol = "SPY";
//	string startday = "01";
//	string startmonth = "01";
//	string endday = "30";
//	string endmonth = "09";
//	vector<string> symbolinformation = { symbol,"",startday,startmonth,endday,endmonth,"","" };
//	Stock ss;
//	ss.LoadStockData(symbolinformation);
//	return ss;
//}
//*/